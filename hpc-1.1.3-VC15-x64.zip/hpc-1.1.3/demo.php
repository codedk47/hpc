<?php
//演示 I/O 服务端
class demo_io extends tcpserver_io
{
	// function __construct()
	// {
	// 	$this->send('Welcome use Windows IOCP PHP Server'.PHP_EOL);
	// 	return $this->buffer_new(1024);
	// }
	function recv()
	{
		// $len = $this->buffer_add();
		// $pos = $this->buffer_pos(PHP_EOL);
		// if($pos > -1)
		// {
		// 	$this->send($this->buffer_cut($pos));
		// }

		//测试简单的echo压力
		$len = $this->read($buf, 8014);
		$this->send($buf);
		return TRUE;
	}
}
//演示 http 服务端
class demo_http extends tcpserver_http
{
 	function recv_req()
	{
		if($this->send_file($this->req_file()) === FALSE)
		{
			switch ($this->req_url())
			{
				case '/hi':
					$this->send_chunked('hi php server');
					break;
				case '/phpinfo':
					$this->send_echo('phpinfo');
					break;
				default:
					$this->send_404();
			}
		}
 		return TRUE;
	}
}
//演示 websocket 服务端
class demo_ws extends tcpserver_ws
{
	function recv_frame()
	{
		//取得帧内容
		$content = $this->frame_content();
		//发送frame
		$this->send_frame($content);
		//编码内容
		$frame = $this->frame_encode($content);
		//发送给其他连接
		$this->send_them($frame);
		return TRUE;
	}
}
//启动tcp服务端
tcpserver(function()
{
	// $this->work_root = 'work'; //设置线程上下文目录（当前服务端路径下的文件夹）
	// $this->thread_class = 'thread'; //设置逻辑线程上下文
	$this->io_class = 'demo_http'; //设置服务器PHP逻辑处理类
	$this->local_socket = 'ssl://*:8014'; //监听本地socket地址，* 代表同时监听IPv6和IPv4地址， 0.0.0.0 或 [::]
	// $this->max_connected = 10000; //服务端最大连接数，不能超过20万
	// $this->kick_timeout = 900; //踢除长时间未数据收发的连接（0为不开启检测）

	// $this->set_ssl('./test.cer','./test.key'); //使用SSL加密通信

	//添加定时器
	// $this->add_timer(function()
	// {
	// 	while(1)
	// 	{
	// 		sleep(2); //每个2秒显示一次在线数
	// 		$this->console_log('Current online %d', $this->get_online());
	// 	}
	// }, time() + 5 ); //服务器启动后5秒开始运行

});