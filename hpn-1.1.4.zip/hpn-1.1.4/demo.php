<?php
hpn(function(){
	$this->bind = 'tcpproxy://hpn_iocp_socket@0.0.0.0:8014';
	// $this->ssl_server('./test.cer','./test.key');
	// $this->ssl_client();
	$this->set_proxy('127.0.0.1', 80);
});